# 真实二胡采样来源与许可记录

## 拟接入来源

| 项目 | 结论 | 用途 |
|---|---|---|
| [Berklee Chinese Erhu Sample Pack](https://remix.berklee.edu/bisa-chinese-erhu/) | 页面明确标注为 **CC BY License**，并提供 Chinese Erhu One Shots、Loops 与多种演奏法集合。 | 作为浏览器二胡练习项目的真实声音来源，需在项目内保留来源与署名。 |
| [Berklee Chinese Erhu One Shots](https://remix.berklee.edu/bisa-chinese-erhu-oneshots/) | 按 Accented、Glissando、Harmonic、Mercato、Tremolo、Vibrato 等演奏法分类。 | 优先选用 Mercato 或 Vibrato 的持续单音，映射本项目音位。 |
| [Zhunghu — Chinese Erhu Loops](https://remix.berklee.edu/bisa-chinese-erhu-loops/2/) | 已确认公开的原生下载入口、54 秒音频、2025 年发布、演奏者 Yu Chun Chan，并保留工程与编辑署名。 | 可作为真实二胡环境声／音色参照；不适合直接逐音映射，因为其为循环段落而非单音。 |

## 许可处理

> 此来源为 CC BY。接入时将在项目的音色来源说明中署名 Berklee Intersectional Soundbox Archive 及采样包贡献者 Yu Chun Chan、Josefina Ugarte、Asher Deverna，并链接原始采样包页面。

## 当前限制

浏览器项目不能依赖会话登录或不稳定的第三方直链。因此在确认可公开下载的音频文件 URL 后，应将采样文件保存在项目的受管静态资源路径并以本地托管 URL 引用；加载失败时保留当前合成器作为自动回退。

当前站点的 One Shots 分类页没有公开可枚举的单音条目 URL，因此不将未确认音高的文件作为按键声音。实施将使用已验证的真实 Zhunghu 样本作为二胡真实音色层，再以合成器处理精确提供各音高，直到获取完整、标注清晰的逐音采样集。

## 已接入资源

- 受管项目资源：`/manus-storage/berklee-zhunghu-erhu-sample_41fcbc02.wav`
- 使用方式：真实二胡样本提供底层弓弦纹理；项目内合成音层维持 D4–D5 等练习音位的准确音高；样本载入失败时自动只使用合成层。
- 页面可见署名：Berklee BISA 采样包，CC BY。
