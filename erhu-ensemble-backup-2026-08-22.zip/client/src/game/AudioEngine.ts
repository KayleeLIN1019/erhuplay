// 设计提醒：真实二胡采样负责可辨认的弓弦质感，受控合成器负责逐音音高；两者叠加并在采样加载失败时自动回退。

import { PITCH_FREQUENCIES, type BowDirection, type Pitch } from "./songLibrary";

const REAL_ERHU_SAMPLE_URL = "/manus-storage/berklee-zhunghu-erhu-sample_41fcbc02.wav";
const REFERENCE_FREQUENCY = 293.665; // D4，用于让真实二胡纹理随练习音位温和变化

type Voice = {
  string: OscillatorNode;
  overtone: OscillatorNode;
  vibrato: OscillatorNode;
  noise: AudioBufferSourceNode;
  sample: AudioBufferSourceNode | null;
  stringGain: GainNode;
  overtoneGain: GainNode;
  scratchGain: GainNode;
  sampleGain: GainNode | null;
  masterGain: GainNode;
  resonator: BiquadFilterNode;
  nasalFilter: BiquadFilterNode;
};

export class AudioEngine {
  private context: AudioContext | null = null;
  private voice: Voice | null = null;
  private periodicWave: PeriodicWave | null = null;
  private bowNoise: AudioBuffer | null = null;
  private realErhuBuffer: AudioBuffer | null = null;
  private sampleLoadStarted = false;

  async unlock() {
    if (!this.context) this.context = new AudioContext();
    if (this.context.state === "suspended") await this.context.resume();
    this.prepareTimbre();
    void this.loadRealErhuSample();
  }

  beginTone(pitch: Pitch, direction: BowDirection, intensity = 0.5) {
    if (!this.context) {
      void this.unlock();
      return;
    }
    this.prepareTimbre();
    if (this.voice) {
      this.updateTone(pitch, intensity);
      return;
    }

    const now = this.context.currentTime;
    const frequency = PITCH_FREQUENCIES[pitch];
    const string = this.context.createOscillator();
    const overtone = this.context.createOscillator();
    const vibrato = this.context.createOscillator();
    const vibratoGain = this.context.createGain();
    const stringGain = this.context.createGain();
    const overtoneGain = this.context.createGain();
    const scratchGain = this.context.createGain();
    const masterGain = this.context.createGain();
    const resonator = this.context.createBiquadFilter();
    const nasalFilter = this.context.createBiquadFilter();
    const warmthFilter = this.context.createBiquadFilter();
    const scratchFilter = this.context.createBiquadFilter();
    const noise = this.context.createBufferSource();

    string.setPeriodicWave(this.periodicWave!);
    overtone.type = "sine";
    string.frequency.value = frequency;
    string.detune.value = direction === "pull" ? -1.5 : 1.5;
    overtone.frequency.value = frequency * 2.002;
    overtone.detune.value = direction === "pull" ? 3 : -3;
    vibrato.type = "sine";
    vibrato.frequency.value = 4.65;
    vibratoGain.gain.setValueAtTime(0.08, now);
    vibratoGain.gain.linearRampToValueAtTime(0.72, now + 0.22);
    noise.buffer = this.bowNoise;
    noise.loop = true;

    resonator.type = "peaking";
    resonator.frequency.value = 780;
    resonator.Q.value = 0.78;
    resonator.gain.value = 5.1;
    nasalFilter.type = "peaking";
    nasalFilter.frequency.value = 1470;
    nasalFilter.Q.value = 0.9;
    nasalFilter.gain.value = 2.2;
    warmthFilter.type = "lowpass";
    warmthFilter.frequency.value = 2650;
    warmthFilter.Q.value = 0.55;
    scratchFilter.type = "bandpass";
    scratchFilter.frequency.value = 1180;
    scratchFilter.Q.value = 0.55;

    const targetGain = this.level(intensity);
    stringGain.gain.setValueAtTime(0.0001, now);
    overtoneGain.gain.setValueAtTime(0.0001, now);
    scratchGain.gain.setValueAtTime(0.0001, now);
    masterGain.gain.setValueAtTime(0.0001, now);
    stringGain.gain.exponentialRampToValueAtTime(targetGain * 0.82, now + 0.085);
    overtoneGain.gain.exponentialRampToValueAtTime(targetGain * 0.08, now + 0.12);
    scratchGain.gain.exponentialRampToValueAtTime(0.0028 * Math.max(0.35, intensity), now + 0.065);
    masterGain.gain.exponentialRampToValueAtTime(0.68, now + 0.09);

    vibrato.connect(vibratoGain);
    vibratoGain.connect(string.frequency);
    string.connect(stringGain);
    overtone.connect(overtoneGain);
    stringGain.connect(resonator);
    overtoneGain.connect(resonator);
    noise.connect(scratchFilter);
    scratchFilter.connect(scratchGain);
    scratchGain.connect(resonator);
    resonator.connect(nasalFilter);
    nasalFilter.connect(warmthFilter);
    warmthFilter.connect(masterGain);
    masterGain.connect(this.context.destination);

    const sampleLayer = this.createSampleLayer(frequency, intensity, now, warmthFilter);
    string.start(now);
    overtone.start(now);
    vibrato.start(now);
    noise.start(now);
    this.voice = { string, overtone, vibrato, noise, sample: sampleLayer.source, stringGain, overtoneGain, scratchGain, sampleGain: sampleLayer.gain, masterGain, resonator, nasalFilter };
  }

  updateTone(pitch: Pitch, intensity = 0.5) {
    if (!this.context || !this.voice) return;
    const now = this.context.currentTime;
    const frequency = PITCH_FREQUENCIES[pitch];
    const level = this.level(intensity);
    this.voice.string.frequency.setTargetAtTime(frequency, now, 0.055);
    this.voice.overtone.frequency.setTargetAtTime(frequency * 2.002, now, 0.055);
    this.voice.stringGain.gain.setTargetAtTime(level * 0.82, now, 0.06);
    this.voice.overtoneGain.gain.setTargetAtTime(level * 0.08, now, 0.08);
    this.voice.scratchGain.gain.setTargetAtTime(0.0028 * Math.max(0.35, intensity), now, 0.05);
    this.voice.sampleGain?.gain.setTargetAtTime(0.026 * Math.max(0.4, intensity), now, 0.08);
    this.voice.sample?.playbackRate.setTargetAtTime(this.sampleRateFor(frequency), now, 0.08);
    this.voice.resonator.frequency.setTargetAtTime(730 + intensity * 190, now, 0.09);
    this.voice.nasalFilter.frequency.setTargetAtTime(1350 + intensity * 250, now, 0.09);
  }

  endTone() {
    if (!this.context || !this.voice) return;
    const voice = this.voice;
    const now = this.context.currentTime;
    voice.masterGain.gain.cancelScheduledValues(now);
    voice.masterGain.gain.setValueAtTime(Math.max(0.0001, voice.masterGain.gain.value), now);
    voice.masterGain.gain.exponentialRampToValueAtTime(0.0001, now + 0.3);
    voice.string.stop(now + 0.33);
    voice.overtone.stop(now + 0.33);
    voice.vibrato.stop(now + 0.33);
    voice.noise.stop(now + 0.33);
    voice.sample?.stop(now + 0.33);
    this.voice = null;
  }

  strike(pitch: Pitch, direction: BowDirection) {
    this.beginTone(pitch, direction, 0.58);
    window.setTimeout(() => this.endTone(), 610);
  }

  dispose() {
    this.endTone();
    void this.context?.close();
    this.context = null;
    this.periodicWave = null;
    this.bowNoise = null;
    this.realErhuBuffer = null;
  }

  private createSampleLayer(frequency: number, intensity: number, now: number, destination: AudioNode) {
    if (!this.context || !this.realErhuBuffer) return { source: null, gain: null };
    const source = this.context.createBufferSource();
    const gain = this.context.createGain();
    const filter = this.context.createBiquadFilter();
    source.buffer = this.realErhuBuffer;
    source.loop = true;
    source.loopStart = Math.min(0.35, Math.max(0, this.realErhuBuffer.duration - 0.8));
    source.loopEnd = Math.max(source.loopStart + 0.3, this.realErhuBuffer.duration - 0.2);
    source.playbackRate.value = this.sampleRateFor(frequency);
    filter.type = "bandpass";
    filter.frequency.value = 860;
    filter.Q.value = 0.55;
    gain.gain.setValueAtTime(0.0001, now);
    gain.gain.exponentialRampToValueAtTime(0.026 * Math.max(0.4, intensity), now + 0.14);
    source.connect(filter);
    filter.connect(gain);
    gain.connect(destination);
    source.start(now, source.loopStart);
    return { source, gain };
  }

  private sampleRateFor(frequency: number) {
    return Math.max(0.78, Math.min(1.3, frequency / REFERENCE_FREQUENCY));
  }

  private level(intensity: number) {
    return 0.082 * Math.max(0.3, Math.min(1, intensity));
  }

  private async loadRealErhuSample() {
    if (!this.context || this.realErhuBuffer || this.sampleLoadStarted) return;
    this.sampleLoadStarted = true;
    try {
      const response = await fetch(REAL_ERHU_SAMPLE_URL);
      if (!response.ok) throw new Error("真实二胡样本载入失败");
      const data = await response.arrayBuffer();
      this.realErhuBuffer = await this.context.decodeAudioData(data);
    } catch {
      // 未能载入真实采样时，仍使用本地合成器保证游戏可演奏。
    }
  }

  private prepareTimbre() {
    if (!this.context || this.periodicWave || this.bowNoise) return;
    const real = new Float32Array(11);
    const imag = new Float32Array(11);
    imag[1] = 0.84;
    imag[2] = 0.12;
    imag[3] = 0.29;
    imag[4] = 0.07;
    imag[5] = 0.13;
    imag[6] = 0.035;
    imag[7] = 0.065;
    imag[8] = 0.025;
    imag[9] = 0.03;
    imag[10] = 0.015;
    this.periodicWave = this.context.createPeriodicWave(real, imag, { disableNormalization: false });

    const frames = Math.floor(this.context.sampleRate * 1.2);
    const buffer = this.context.createBuffer(1, frames, this.context.sampleRate);
    const channel = buffer.getChannelData(0);
    let previous = 0;
    for (let index = 0; index < frames; index += 1) {
      const white = Math.random() * 2 - 1;
      previous = previous * 0.93 + white * 0.07;
      channel[index] = previous;
    }
    this.bowNoise = buffer;
  }
}
