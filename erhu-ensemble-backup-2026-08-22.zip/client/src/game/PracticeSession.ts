// 设计提醒：练习采用逐音推进，而不是倒计时追赶；每一次正确的拉弓都是向下一枚朱砂音符迈进一步。

import type { BowDirection, Pitch, Song } from "./songLibrary";

export type SessionStatus = "idle" | "playing" | "paused" | "finished";

export type PracticeSnapshot = {
  status: SessionStatus;
  elapsed: number;
  activeIndex: number;
  score: number;
  combo: number;
  maxCombo: number;
  correct: number;
  misses: number;
  beatProgress: number;
  message: string;
  accuracy: number;
};

export class PracticeSession {
  private status: SessionStatus = "idle";
  private elapsed = 0;
  private lastTime = 0;
  private active = 0;
  private score = 0;
  private combo = 0;
  private maxCombo = 0;
  private correct = 0;
  private misses = 0;
  private message = "选好音位，拉对这一声再往下走";

  constructor(readonly song: Song) {}

  start(now = performance.now()) {
    if (this.status === "finished") this.reset();
    this.status = "playing";
    this.lastTime = now;
    this.message = "不赶拍，拉对当前音才会进入下一音。";
  }

  pause() {
    if (this.status !== "playing") return;
    this.status = "paused";
    this.message = "已停在当前音，准备好再继续。";
  }

  reset() {
    this.status = "idle";
    this.elapsed = 0;
    this.lastTime = 0;
    this.active = 0;
    this.score = 0;
    this.combo = 0;
    this.maxCombo = 0;
    this.correct = 0;
    this.misses = 0;
    this.message = "从第一音重新开始，慢慢拉稳。";
  }

  update(now = performance.now()) {
    if (this.status !== "playing") return;
    const delta = Math.min(100, now - this.lastTime);
    this.elapsed += delta;
    this.lastTime = now;
  }

  perform(pitch: Pitch, bow: BowDirection) {
    if (this.status !== "playing" || this.active >= this.song.notes.length) return false;
    const target = this.song.notes[this.active];
    const matched = target.pitch === pitch && target.bow === bow;

    if (!matched) {
      this.misses += 1;
      this.combo = 0;
      this.message = target.pitch !== pitch ? `这一音试试 ${target.label}，不急，音符会等你。` : `这一音要用${target.bow === "pull" ? "拉" : "推"}弓，再试一次。`;
      return false;
    }

    this.correct += 1;
    this.combo += 1;
    this.maxCombo = Math.max(this.maxCombo, this.combo);
    this.score += 100 + Math.max(0, this.combo - 1) * 10;
    this.active += 1;

    if (this.active >= this.song.notes.length) {
      this.status = "finished";
      this.message = "这一曲已走完，每一音都由你亲手拉出。";
    } else {
      const next = this.song.notes[this.active];
      this.message = this.combo >= 4 ? `连弓很稳，下一音是 ${next.label}。` : `正中这一音，准备 ${next.label}。`;
    }
    return true;
  }

  snapshot(): PracticeSnapshot {
    return {
      status: this.status,
      elapsed: this.elapsed,
      activeIndex: Math.min(this.active, this.song.notes.length - 1),
      score: this.score,
      combo: this.combo,
      maxCombo: this.maxCombo,
      correct: this.correct,
      misses: this.misses,
      beatProgress: this.status === "playing" ? 0.9 : 0.42,
      message: this.message,
      accuracy: this.accuracy(),
    };
  }

  private accuracy() {
    const judged = this.correct + this.misses;
    return judged === 0 ? 100 : Math.round((this.correct / judged) * 100);
  }
}
