// 设计提醒：程序化二胡置于宣纸舞台中央，以深胡桃木、烟墨和朱砂红建立安静的视觉锚点。

import { ArcRotateCamera } from "@babylonjs/core/Cameras/arcRotateCamera";
import { Color3, Color4 } from "@babylonjs/core/Maths/math.color";
import { Vector3 } from "@babylonjs/core/Maths/math.vector";
import { Engine } from "@babylonjs/core/Engines/engine";
import { HemisphericLight } from "@babylonjs/core/Lights/hemisphericLight";
import { PointLight } from "@babylonjs/core/Lights/pointLight";
import { StandardMaterial } from "@babylonjs/core/Materials/standardMaterial";
import { MeshBuilder } from "@babylonjs/core/Meshes/meshBuilder";
import { Scene } from "@babylonjs/core/scene";
import { TransformNode } from "@babylonjs/core/Meshes/transformNode";
import type { BowDirection, Pitch } from "./songLibrary";

export type GameHandle = {
  scene: Scene;
  setPitch: (pitch: Pitch) => void;
  setBow: (direction: BowDirection, intensity: number, active: boolean) => void;
  dispose: () => void;
};

const CRIMSON = new Color3(0.784, 0.235, 0.18);
const INK = new Color3(0.12, 0.105, 0.085);
const WALNUT = new Color3(0.105, 0.048, 0.022);

export async function createGameScene(engine: Engine, canvas: HTMLCanvasElement): Promise<GameHandle> {
  const scene = new Scene(engine);
  scene.clearColor = new Color4(0, 0, 0, 0);

  const camera = new ArcRotateCamera("erhu-camera", Math.PI / 2, Math.PI / 2.28, 7.1, new Vector3(0.25, -0.05, 0), scene);
  camera.lowerRadiusLimit = 6.5;
  camera.upperRadiusLimit = 7.4;
  camera.wheelPrecision = 999999;
  camera.attachControl(canvas, false);

  const ambient = new HemisphericLight("paper-light", new Vector3(0, 1, 0), scene);
  ambient.intensity = 0.78;
  ambient.diffuse = new Color3(0.94, 0.88, 0.78);
  ambient.groundColor = new Color3(0.18, 0.12, 0.08);
  const warmLight = new PointLight("warm-light", new Vector3(-3, 3.5, 3), scene);
  warmLight.intensity = 5;
  warmLight.diffuse = new Color3(0.8, 0.56, 0.34);

  const root = new TransformNode("erhu-root", scene);
  root.position = new Vector3(0.76, -0.18, 0);
  root.scaling.setAll(0.9);

  const wood = new StandardMaterial("dark-walnut", scene);
  wood.diffuseColor = WALNUT;
  wood.emissiveColor = new Color3(0.01, 0.004, 0.002);
  wood.specularColor = new Color3(0.025, 0.01, 0.004);
  const blackWood = new StandardMaterial("ink-wood", scene);
  blackWood.diffuseColor = INK;
  blackWood.specularColor = new Color3(0.05, 0.04, 0.03);
  const ivory = new StandardMaterial("horsehair", scene);
  ivory.diffuseColor = new Color3(0.56, 0.49, 0.39);
  ivory.emissiveColor = new Color3(0.018, 0.014, 0.01);
  const crimson = new StandardMaterial("vermilion-thread", scene);
  crimson.diffuseColor = CRIMSON;
  crimson.emissiveColor = new Color3(0.12, 0.015, 0.01);

  const neck = MeshBuilder.CreateCylinder("erhu-neck", { height: 4.15, diameter: 0.115, tessellation: 10 }, scene);
  neck.parent = root;
  neck.position.y = 0.14;
  neck.material = blackWood;

  const cap = MeshBuilder.CreateSphere("erhu-cap", { diameter: 0.19, segments: 12 }, scene);
  cap.parent = root;
  cap.position.y = 2.2;
  cap.material = wood;

  const desk = MeshBuilder.CreateBox("walnut-desk", { width: 3.35, height: 0.16, depth: 1.5 }, scene);
  desk.parent = root;
  desk.position = new Vector3(0, -2.28, -0.36);
  desk.material = wood;

  const resonator = MeshBuilder.CreateCylinder("erhu-resonator", { height: 0.56, diameter: 0.92, tessellation: 6 }, scene);
  resonator.parent = root;
  resonator.rotation.x = Math.PI / 2;
  resonator.position.y = -1.92;
  resonator.material = wood;

  const skin = MeshBuilder.CreateDisc("resonator-skin", { radius: 0.37, tessellation: 6 }, scene);
  skin.parent = root;
  skin.position = new Vector3(0, -1.92, 0.285);
  skin.material = ivory;

  [-0.22, 0.22].forEach((y, index) => {
    const peg = MeshBuilder.CreateCylinder(`peg-${index}`, { height: 0.48, diameter: 0.105, tessellation: 8 }, scene);
    peg.parent = root;
    peg.rotation.z = Math.PI / 2;
    peg.position = new Vector3(index === 0 ? -0.1 : 0.1, 1.18 + y, 0);
    peg.material = wood;
  });

  const bridge = MeshBuilder.CreateBox("bridge", { width: 0.2, height: 0.35, depth: 0.12 }, scene);
  bridge.parent = root;
  bridge.position = new Vector3(0, -1.7, 0.25);
  bridge.material = ivory;

  const strings = [-0.053, 0.053].map((x, index) => {
    const string = MeshBuilder.CreateLines(
      `string-${index}`,
      { points: [new Vector3(x, 2.0, 0.1), new Vector3(x * 0.6, -1.88, 0.29)] },
      scene,
    );
    string.parent = root;
    string.color = new Color3(0.5, 0.42, 0.3);
    return string;
  });

  const bowRoot = new TransformNode("bow-root", scene);
  bowRoot.parent = root;
  bowRoot.position = new Vector3(0, -0.15, 0.42);
  const bowStick = MeshBuilder.CreateCylinder("bow-stick", { height: 4.25, diameter: 0.06, tessellation: 8 }, scene);
  bowStick.parent = bowRoot;
  bowStick.rotation.z = Math.PI / 2;
  bowStick.position.y = 0.15;
  bowStick.material = wood;
  const bowHair = MeshBuilder.CreateCylinder("bow-hair", { height: 3.9, diameter: 0.024, tessellation: 6 }, scene);
  bowHair.parent = bowRoot;
  bowHair.rotation.z = Math.PI / 2;
  bowHair.position.y = -0.12;
  bowHair.material = ivory;

  const seal = MeshBuilder.CreateTorus("timing-seal", { diameter: 0.5, thickness: 0.07, tessellation: 20 }, scene);
  seal.parent = root;
  seal.position = new Vector3(0.68, -0.75, -0.1);
  seal.rotation.x = Math.PI / 2;
  seal.material = crimson;

  let activePitch: Pitch = "D4";
  let bowDirection: BowDirection = "pull";
  let bowIntensity = 0;
  let bowActive = false;
  let elapsed = 0;
  let compactLayout: boolean | null = null;

  const applyStageLayout = () => {
    const shouldCompact = window.innerWidth <= 640;
    if (shouldCompact === compactLayout) return;
    compactLayout = shouldCompact;
    if (shouldCompact) {
      root.setEnabled(false);
    } else {
      root.setEnabled(true);
      root.position.x = 0.76;
      root.position.y = -0.18;
      root.scaling.setAll(0.9);
    }
  };

  scene.onBeforeRenderObservable.add(() => {
    applyStageLayout();
    const delta = scene.getEngine().getDeltaTime() / 1000;
    elapsed += delta;
    root.rotation.y = Math.sin(elapsed * 0.62) * 0.035;
    if (bowActive) {
      const motion = Math.sin(elapsed * (6 + bowIntensity * 10)) * (0.16 + bowIntensity * 0.18);
      bowRoot.position.x = (bowDirection === "pull" ? motion : -motion);
      bowRoot.rotation.z = (bowDirection === "pull" ? 1 : -1) * 0.018;
      seal.scaling.setAll(1 + Math.sin(elapsed * 10) * 0.04 + bowIntensity * 0.08);
    } else {
      bowRoot.position.x *= 0.88;
      bowRoot.rotation.z *= 0.82;
      seal.scaling.setAll(1);
    }
    strings.forEach((string, index) => {
      const isSelected = (activePitch.includes("4") && index === 0) || (activePitch.includes("5") && index === 1);
      string.color = isSelected && bowActive ? CRIMSON : new Color3(0.5, 0.42, 0.3);
    });
  });

  return {
    scene,
    setPitch: (pitch) => {
      activePitch = pitch;
    },
    setBow: (direction, intensity, active) => {
      bowDirection = direction;
      bowIntensity = intensity;
      bowActive = active;
    },
    dispose: () => scene.dispose(),
  };
}
