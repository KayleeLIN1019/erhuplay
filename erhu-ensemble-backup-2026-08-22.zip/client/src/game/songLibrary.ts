// 设计提醒：本模块服务“墨韵练功房”，以简短、可辨识的音符序列让初学者专注节拍与弓向。

export type BowDirection = "push" | "pull";

export type SongNote = {
  pitch: Pitch;
  label: string;
  bow: BowDirection;
};

export type Pitch = "D4" | "E4" | "F#4" | "G4" | "A4" | "B4" | "C#5" | "D5";

export type Song = {
  id: string;
  title: string;
  subtitle: string;
  tempo: number;
  notes: SongNote[];
};

const notes = (pitches: Pitch[]): SongNote[] =>
  pitches.map((pitch, index) => ({
    pitch,
    label: pitch.replace("#", "♯").replace(/[0-9]/, ""),
    bow: index % 2 === 0 ? "pull" : "push",
  }));

export const PITCHES: Pitch[] = ["D4", "E4", "F#4", "G4", "A4", "B4", "C#5", "D5"];

export const SONGS: Song[] = [
  {
    id: "little-star",
    title: "小星星",
    subtitle: "八拍入门 · 熟悉音位",
    tempo: 72,
    notes: notes(["D4", "D4", "A4", "A4", "B4", "B4", "A4", "G4", "G4", "F#4", "F#4", "E4", "E4", "D4"]),
  },
  {
    id: "jasmine",
    title: "茉莉花",
    subtitle: "十六拍 · 练习换弦",
    tempo: 84,
    notes: notes(["E4", "G4", "A4", "G4", "E4", "D4", "E4", "G4", "A4", "B4", "A4", "G4", "E4", "G4", "A4", "D5"]),
  },
  {
    id: "horse-race",
    title: "赛马片段",
    subtitle: "十六拍 · 保持推拉节奏",
    tempo: 104,
    notes: notes(["D4", "F#4", "A4", "D5", "A4", "F#4", "D4", "E4", "F#4", "G4", "A4", "B4", "D5", "B4", "A4", "F#4"]),
  },
];

export const PITCH_FREQUENCIES: Record<Pitch, number> = {
  D4: 293.66,
  E4: 329.63,
  "F#4": 369.99,
  G4: 392,
  A4: 440,
  B4: 493.88,
  "C#5": 554.37,
  D5: 587.33,
};

