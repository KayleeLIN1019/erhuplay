// 设计提醒：根路由只承载全屏的“墨韵练功房”画框，避免额外应用页面分散演奏注意力。

import GameCanvas from "@/components/GameCanvas";

export default function App() {
  return <GameCanvas />;
}

