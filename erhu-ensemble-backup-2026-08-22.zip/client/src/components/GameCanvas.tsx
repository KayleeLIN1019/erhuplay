// 设计提醒：本组件是“墨韵练功房”的完整画框；界面保持克制，把注意力留给纸谱、音位与琴弓。

import { useEffect, useRef, useState } from "react";
import { Engine } from "@babylonjs/core/Engines/engine";
import { ArrowLeft, ArrowRight, CircleDot, ChevronLeft, ChevronRight, Hand, Music2, Pause, Play, RotateCcw, Sparkles, Volume2 } from "lucide-react";
import { Dialog, DialogContent, DialogDescription, DialogTitle } from "@/components/ui/dialog";
import { AudioEngine } from "@/game/AudioEngine";
import { PracticeSession, type PracticeSnapshot } from "@/game/PracticeSession";
import { PITCHES, SONGS, type BowDirection, type Pitch, type Song } from "@/game/songLibrary";
import { createGameScene, type GameHandle } from "@/game/scene";

const LOGO_URL = "/manus-storage/erhu-brand-mark_9e12c1c3.png";
const ERHU_ART_URL = "/manus-storage/erhu-practice-hero_809b7f06.png";

type PointerState = {
  id: number;
  startX: number;
  triggered: boolean;
};

const getPitchLabel = (pitch: Pitch) => pitch.replace("#", "♯").replace(/[0-9]/, "");

const GUIDE_STEPS = [
  { icon: CircleDot, eyebrow: "第一步 · 按弦", title: "先选准这一声", body: "从左侧的音位纸签中点选音名。D、E、F♯、G 是内弦基础音，键盘 1–8 也能快速切换。", cue: "点选左侧音位", accent: "D" },
  { icon: Hand, eyebrow: "第二步 · 持弓", title: "让弓横向走过琴弦", body: "在右侧弓区按住后横向拖动：向左是推弓，向右是拉弓。拖得更稳，声音也会更连贯。", cue: "按住拖动弓区", accent: "↔" },
  { icon: Music2, eyebrow: "第三步 · 跟谱", title: "拉对一音，再进一音", body: "点“开始练习”后，纸谱会停在当前朱砂音符。选对音位与弓向，拉完这一音才会出现下一音，不必追赶节拍。", cue: "开始第一首练习", accent: "稳" },
];

export default function GameCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const startedRef = useRef(false);
  const handleRef = useRef<GameHandle | null>(null);
  const audioRef = useRef<AudioEngine>(new AudioEngine());
  const sessionRef = useRef<PracticeSession>(new PracticeSession(SONGS[0]));
  const pointerRef = useRef<PointerState | null>(null);
  const [song, setSong] = useState<Song>(SONGS[0]);
  const [pitch, setPitch] = useState<Pitch>("D4");
  const [snapshot, setSnapshot] = useState<PracticeSnapshot>(() => sessionRef.current.snapshot());
  const [lastDirection, setLastDirection] = useState<BowDirection>("pull");
  const [bowPosition, setBowPosition] = useState(50);
  const [isDemo] = useState(() => new URLSearchParams(window.location.search).has("demo"));
  const [guideStep, setGuideStep] = useState(0);
  const [guideOpen, setGuideOpen] = useState(() => {
    const query = new URLSearchParams(window.location.search);
    if (query.has("demo") || query.has("skipguide")) return false;
    return window.sessionStorage.getItem("erhu-practice-guide-seen") !== "yes";
  });

  const refresh = () => setSnapshot(sessionRef.current.snapshot());

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || startedRef.current) return;
    startedRef.current = true;
    const engine = new Engine(canvas, true, { preserveDrawingBuffer: true, stencil: true, adaptToDeviceRatio: true });
    let handle: GameHandle | null = null;
    createGameScene(engine, canvas).then((nextHandle) => {
      handle = nextHandle;
      handleRef.current = nextHandle;
      nextHandle.setPitch(pitch);
      engine.runRenderLoop(() => nextHandle.scene.render());
    });
    const onResize = () => engine.resize();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      handle?.dispose();
      engine.dispose();
      handleRef.current = null;
      startedRef.current = false;
    };
  }, []);

  useEffect(() => {
    const timer = window.setInterval(() => {
      sessionRef.current.update();
      setSnapshot(sessionRef.current.snapshot());
    }, 60);
    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!isDemo) return;
    let playedIndex = -1;
    const startTimer = window.setTimeout(() => {
      sessionRef.current.start();
      const first = song.notes[0];
      setPitch(first.pitch);
      handleRef.current?.setPitch(first.pitch);
      refresh();
    }, 350);
    const demoTimer = window.setInterval(() => {
      const next = sessionRef.current.snapshot();
      if (next.status !== "playing" || next.activeIndex === playedIndex) return;
      const note = song.notes[next.activeIndex];
      if (!note) return;
      playedIndex = next.activeIndex;
      setPitch(note.pitch);
      setLastDirection(note.bow);
      handleRef.current?.setPitch(note.pitch);
      handleRef.current?.setBow(note.bow, 0.68, true);
      sessionRef.current.perform(note.pitch, note.bow);
      window.setTimeout(() => handleRef.current?.setBow(note.bow, 0, false), 260);
      refresh();
    }, 760);
    return () => {
      window.clearTimeout(startTimer);
      window.clearInterval(demoTimer);
    };
  }, [isDemo, song]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      const index = Number(event.key) - 1;
      if (index >= 0 && index < PITCHES.length) {
        choosePitch(PITCHES[index]);
        return;
      }
      if (event.key === " " || event.key === "ArrowLeft" || event.key === "ArrowRight") {
        event.preventDefault();
        const direction: BowDirection = event.key === "ArrowLeft" ? "push" : "pull";
        performKeyboardBow(direction);
      }
    };
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  });

  useEffect(() => () => audioRef.current.dispose(), []);

  function choosePitch(nextPitch: Pitch) {
    setPitch(nextPitch);
    handleRef.current?.setPitch(nextPitch);
  }

  async function startOrPause() {
    await audioRef.current.unlock();
    if (snapshot.status === "playing") sessionRef.current.pause();
    else sessionRef.current.start();
    refresh();
  }

  function restart() {
    audioRef.current.endTone();
    sessionRef.current.reset();
    handleRef.current?.setBow(lastDirection, 0, false);
    refresh();
  }

  function changeSong(nextSong: Song) {
    audioRef.current.endTone();
    setSong(nextSong);
    sessionRef.current = new PracticeSession(nextSong);
    choosePitch(nextSong.notes[0].pitch);
    refresh();
  }

  function closeGuide() {
    window.sessionStorage.setItem("erhu-practice-guide-seen", "yes");
    setGuideOpen(false);
  }

  function moveGuide(direction: "back" | "next") {
    if (direction === "back") {
      setGuideStep((currentStep) => Math.max(0, currentStep - 1));
      return;
    }
    if (guideStep === GUIDE_STEPS.length - 1) {
      closeGuide();
      return;
    }
    setGuideStep((currentStep) => currentStep + 1);
  }

  function performKeyboardBow(direction: BowDirection) {
    if (snapshot.status !== "playing") return;
    void audioRef.current.unlock().then(() => audioRef.current.strike(pitch, direction));
    handleRef.current?.setBow(direction, 0.58, true);
    window.setTimeout(() => handleRef.current?.setBow(direction, 0, false), 250);
    setLastDirection(direction);
    sessionRef.current.perform(pitch, direction);
    refresh();
  }

  function onBowStart(event: React.PointerEvent<HTMLButtonElement>) {
    event.currentTarget.setPointerCapture(event.pointerId);
    pointerRef.current = { id: event.pointerId, startX: event.clientX, triggered: false };
    const rect = event.currentTarget.getBoundingClientRect();
    setBowPosition(Math.max(8, Math.min(92, ((event.clientX - rect.left) / rect.width) * 100)));
    void audioRef.current.unlock();
  }

  function onBowMove(event: React.PointerEvent<HTMLButtonElement>) {
    const pointer = pointerRef.current;
    if (!pointer || pointer.id !== event.pointerId) return;
    const rect = event.currentTarget.getBoundingClientRect();
    setBowPosition(Math.max(8, Math.min(92, ((event.clientX - rect.left) / rect.width) * 100)));
    const delta = event.clientX - pointer.startX;
    if (Math.abs(delta) < 9) return;
    const direction: BowDirection = delta > 0 ? "pull" : "push";
    const intensity = Math.min(1, Math.abs(delta) / 140 + 0.3);
    setLastDirection(direction);
    handleRef.current?.setBow(direction, intensity, true);
    audioRef.current.beginTone(pitch, direction, intensity);
    audioRef.current.updateTone(pitch, intensity);
    if (!pointer.triggered && snapshot.status === "playing") {
      pointer.triggered = true;
      sessionRef.current.perform(pitch, direction);
      refresh();
    }
  }

  function onBowEnd(event: React.PointerEvent<HTMLButtonElement>) {
    if (pointerRef.current?.id !== event.pointerId) return;
    pointerRef.current = null;
    audioRef.current.endTone();
    handleRef.current?.setBow(lastDirection, 0, false);
    setBowPosition(50);
  }

  const current = song.notes[snapshot.activeIndex] ?? song.notes[song.notes.length - 1];
  const visibleNotes = song.notes.slice(snapshot.activeIndex, snapshot.activeIndex + 6);
  const isPlaying = snapshot.status === "playing";
  const isFinished = snapshot.status === "finished";
  const activeGuide = GUIDE_STEPS[guideStep];
  const GuideIcon = activeGuide.icon;

  return (
    <main className="game-shell" aria-label="弦上二胡演奏练习">
      <canvas ref={canvasRef} className="game-canvas" style={{ touchAction: "none" }} />
      <div className="paper-grain" aria-hidden="true" />
      <div className="erhu-stage" aria-hidden="true">
        <img src={ERHU_ART_URL} alt="" />
        <span className="stage-instrument-line" />
        <span className="stage-instrument-bridge" />
        <span className="stage-bow-trail" />
        <span className="stage-seal">弦</span>
      </div>
      <div className="mobile-erhu-ghost" aria-hidden="true">
        <span className="ghost-neck" />
        <span className="ghost-bow" />
        <span className="ghost-body" />
      </div>
      <div className="game-ui">
        <header className="topbar">
          <div className="brand-lockup">
            <img src={LOGO_URL} alt="弦上二胡标志" className="brand-mark" />
            <div>
              <p className="eyebrow">ERHU PRACTICE ROOM</p>
              <h1>弦上二胡</h1>
            </div>
          </div>
          <div className="topbar-center">拉稳这一音，再向下一音</div>
          <button type="button" className="guide-reopen" onClick={() => { setGuideStep(0); setGuideOpen(true); }}>
            <Sparkles size={13} strokeWidth={1.8} />
            <span>练习说明</span>
          </button>
          <div className="score-stack" aria-label="当前成绩">
            <span>得分</span>
            <strong>{String(snapshot.score).padStart(4, "0")}</strong>
          </div>
        </header>

        <section className="song-card" aria-label="曲目选择">
          <span className="section-label">曲目引导</span>
          <div className="song-picker">
            {SONGS.map((item, index) => (
              <button key={item.id} type="button" className={item.id === song.id ? "song-option active" : "song-option"} onClick={() => changeSong(item)}>
                <b>0{index + 1}</b>
                <span>{item.title}</span>
              </button>
            ))}
          </div>
          <p className="song-subtitle">{song.subtitle}</p>
        </section>

        <section className="score-ribbon" aria-label="当前乐谱">
          <div className="ribbon-intro">
            <span className="section-label">当前一音</span>
            <strong>{song.title}</strong>
          </div>
          <div className="note-lane">
            {visibleNotes.map((note, index) => {
              const isCurrent = index === 0;
              return (
                <div className={isCurrent ? "note-token current" : "note-token"} key={`${note.pitch}-${snapshot.activeIndex + index}`}>
                  <span>{note.label}</span>
                  <i>{note.bow === "pull" ? "拉" : "推"}</i>
                </div>
              );
            })}
            <div className="timing-seal" style={{ "--beat": snapshot.beatProgress } as React.CSSProperties} aria-hidden="true" />
          </div>
          <div className="ribbon-progress"><span style={{ width: `${Math.min(100, (snapshot.activeIndex / song.notes.length) * 100)}%` }} /></div>
        </section>

        <section className="finger-rack" aria-label="音位选择">
          <span className="section-label">按弦选音</span>
          <p>键盘 1–8 也可切换</p>
          <div className="pitch-list">
            {PITCHES.map((item, index) => (
              <button key={item} type="button" onClick={() => choosePitch(item)} className={pitch === item ? "pitch-pad active" : "pitch-pad"} aria-pressed={pitch === item}>
                <em>{index + 1}</em>
                <span>{getPitchLabel(item)}</span>
                <small>{item.endsWith("5") ? "外弦" : "内弦"}</small>
              </button>
            ))}
          </div>
        </section>

        <section className="bow-station" aria-label="拉弓控制">
          <span className="section-label">持弓演奏</span>
          <p>这一弓，横向走</p>
          <button
            type="button"
            className={`${isPlaying ? "bow-pad playing" : "bow-pad"} ${current.bow === "pull" ? "target-pull" : "target-push"}`}
            onPointerDown={onBowStart}
            onPointerMove={onBowMove}
            onPointerUp={onBowEnd}
            onPointerCancel={onBowEnd}
            aria-label="拖动此区域拉弓演奏"
          >
            <span className="bow-track" />
            <span className="bow-handle" style={{ left: `${bowPosition}%` }}><Volume2 size={19} strokeWidth={1.8} /></span>
            <span className="bow-direction left">推弓 ←</span>
            <span className="bow-direction right">→ 拉弓</span>
            <span className="bow-target-guide" aria-hidden="true">
              {current.bow === "pull" ? <ArrowRight size={30} strokeWidth={1.55} /> : <ArrowLeft size={30} strokeWidth={1.55} />}
            </span>
          </button>
          <div className={`bow-instruction ${current.bow === "pull" ? "pull" : "push"}`} aria-live="polite">
            {current.bow === "pull" ? <ArrowRight size={17} strokeWidth={2} /> : <ArrowLeft size={17} strokeWidth={2} />}
            <strong>{current.bow === "pull" ? "这一音：向右拉弓" : "这一音：向左推弓"}</strong>
            <span>· {current.label}</span>
          </div>
          <p className="last-motion">刚才：{lastDirection === "pull" ? "拉弓" : "推弓"}</p>
          <a className="sample-attribution" href="https://remix.berklee.edu/bisa-chinese-erhu/" target="_blank" rel="noreferrer">真实二胡纹理由 Berklee BISA 采样包提供 · CC BY</a>
        </section>

        <footer className="practice-dock">
          <div className={isFinished ? "feedback finished" : "feedback"}>
            <span className="feedback-dot" />
            <p>{isFinished ? `完成 ${snapshot.correct}/${song.notes.length} 音 · 准确率 ${snapshot.accuracy}%` : snapshot.message}</p>
          </div>
          <div className="dock-controls">
            <button type="button" className="round-control" onClick={restart} aria-label="重新开始"><RotateCcw size={18} strokeWidth={1.8} /></button>
            <button type="button" className="main-control" onClick={startOrPause}>
              {isPlaying ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}
              <span>{isPlaying ? "暂停练习" : isFinished ? "再奏一遍" : "开始练习"}</span>
            </button>
          </div>
          <div className="combo-readout"><span>连击</span><strong>×{snapshot.combo}</strong></div>
        </footer>

        {snapshot.status === "idle" && <div className="start-hint">先点「开始练习」，拉对当前音才会进入下一音。</div>}
      </div>

      <Dialog open={guideOpen} onOpenChange={(open) => { if (!open) closeGuide(); }}>
        <DialogContent showCloseButton={false} className="onboarding-sheet">
          <div className="guide-paper-corner" aria-hidden="true" />
          <button type="button" className="guide-skip" onClick={closeGuide}>跳过指引</button>
          <div className="guide-index" aria-label={`第 ${guideStep + 1} 步，共 ${GUIDE_STEPS.length} 步`}>
            {GUIDE_STEPS.map((_, index) => <span key={index} className={index === guideStep ? "active" : ""} />)}
          </div>
          <div className="guide-visual" aria-hidden="true">
            <GuideIcon size={42} strokeWidth={1.3} />
            <span>{activeGuide.accent}</span>
          </div>
          <p className="guide-eyebrow">{activeGuide.eyebrow}</p>
          <DialogTitle className="guide-title">{activeGuide.title}</DialogTitle>
          <DialogDescription className="guide-description">{activeGuide.body}</DialogDescription>
          <div className="guide-cue"><i /><span>{activeGuide.cue}</span></div>
          <div className="guide-actions">
            <button type="button" className="guide-back" onClick={() => moveGuide("back")} disabled={guideStep === 0}><ChevronLeft size={17} />上一步</button>
            <button type="button" className="guide-next" onClick={() => moveGuide("next")}>{guideStep === GUIDE_STEPS.length - 1 ? "开始练习" : "下一步"}<ChevronRight size={17} /></button>
          </div>
        </DialogContent>
      </Dialog>
    </main>
  );
}
