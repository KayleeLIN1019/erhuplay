# Assets

**Art direction:** 当代东方极简的二胡练功房。主画面为暖米白宣纸，深墨、胡桃木与少量朱砂红建立节拍和命中层级；结构简洁、可操作、具有轻微纸纤维和游丝笔触，而不使用复杂室内、人物、浓重古风装饰或难以复现的特效。

| 资产 | 用途 | URL | 状态 |
| --- | --- | --- | --- |
| 游戏构图参考 | 用作视觉 QA 基准 | `/manus-storage/erhu-game-reference_2916752d.png` | 生成中，完成后自动替换 |
| 宣纸声景 | 全屏场景背景 | `/manus-storage/xuan-paper-soundscape_66753363.png` | 生成中，完成后自动替换 |
| 二胡漆木细节 | 材质、配色与程序化二胡细节参考 | `/manus-storage/erhu-lacquer-detail_b6a4b664.png` | 生成中，完成后自动替换 |
| 墨点弓迹 | 纸谱与拖弓区域的轻纹理 | `/manus-storage/ink-note-trail_7bdfb112.png` | 生成中，完成后自动替换 |
| 弓弦图标 | 顶栏品牌符号及 favicon | `/manus-storage/erhu-brand-mark_9e12c1c3.png` | 生成中，完成后自动替换 |

二胡本体采用 Babylon 的细柱体、弦线与鼓身形状构成；不需要导入 GLB 资产。

