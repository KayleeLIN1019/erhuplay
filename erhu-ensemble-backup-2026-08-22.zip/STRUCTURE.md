# Game Structure: 弦上二胡

## 层次

```text
React App
└── GameCanvas（全屏舞台、DOM 交互面板与生命周期）
    └── Babylon Scene
        └── GameWorld（场景、二胡几何、琴弓几何与更新循环）

Plain TypeScript Game Modules
├── AudioEngine        Web Audio 单音合成与包络控制
├── InputController    拖弓、键盘与音位选择的语义动作
├── PracticeSession    歌曲时间线、判定、得分、暂停与完成状态机
├── songLibrary        曲目数据与音高映射
└── scene              创建与销毁 Babylon 场景、公开 GameHandle
```

## 关键对象职责

| 模块 | 职责 | 不负责 |
| --- | --- | --- |
| `GameCanvas` | 初始化引擎、绑定输入、向 UI 发布状态、在组件销毁时回收资源 | 歌曲判定算法与音频振荡器细节 |
| `GameWorld` | 创建二胡、琴弦、弓、桌面和背景；接收演奏状态更新 | React 状态与歌曲选择逻辑 |
| `AudioEngine` | 解锁音频上下文、按音名和弓速起止声音 | 显示和判定 |
| `PracticeSession` | 提供当前待奏音、时间窗、分数、连击、准确率与完成结算 | 场景网格或 DOM 操作 |
| `InputController` | 把键盘与指针转换为 `selectNote`、`bowStart`、`bowMove`、`bowEnd` | 直接操纵 Babylon 节点 |

## 数据模型

```ts
type BowDirection = "push" | "pull";
type SongNote = {
  pitch: "D4" | "E4" | "F#4" | "G4" | "A4" | "B4" | "C#5" | "D5";
  label: string;
  beat: number;
  duration: number;
  bow: BowDirection;
};

type SessionState = "idle" | "playing" | "paused" | "finished";
```

## 生命周期

`createGameScene(engine, canvas)` 创建 `GameWorld` 与灯光相机，返回 `GameHandle`。`GameCanvas` 的一次性 effect 守卫 StrictMode 双装载，在卸载时移除事件、停止渲染并调用 `GameHandle.dispose()`。音频仅在用户动作后初始化。

